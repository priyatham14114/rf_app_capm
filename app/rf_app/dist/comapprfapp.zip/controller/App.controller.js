sap.ui.define(["sap/ui/core/mvc/Controller"],function(n){"use strict";return n.extend("com.app.rfapp.controller.App",{onInit:function(){}})});
//# sourceMappingURL=App.controller.js.map